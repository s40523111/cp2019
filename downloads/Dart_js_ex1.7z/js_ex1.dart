// 將 js_ex1.dart 轉為 javascript 檔案 js_ex1.js
//dart2js -o js_ex1.js js_ex1.dart
// 導入 package 中的程式庫
import 'package:js/js.dart';

// 宣告外部 Javascript 程式庫中的 alert 函式
@JS()
external void alert(String str);

main(){
    // 呼叫 alert 函式, 顯示出字串
    alert('哈囉! 利用 dart2js 批次檔案將 dart 轉為 javascript');
}