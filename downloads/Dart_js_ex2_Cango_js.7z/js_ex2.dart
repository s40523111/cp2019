import './cango.dart';

import 'dart:html';
//import 'dart:core';
import 'dart:math' as math;
import 'package:js/js.dart';

CanvasElement canvas;
CanvasRenderingContext2D ctx;

// n 為齒數, m 為模數, pa 為壓力角
cangoGear(int n, num m, num pa){
    int i;
    // pr 為節圓半徑 pitch circle radius
    num pr = n*m/2;
    num rb = pr*math.cos(pa*math.pi/180);
    // tooth 為單一齒的齒形數據
    var tooth = createGearTooth(m, n, pa);
    // 利用齒形數據, 建立 SVGsegs 片段資料
    var toothData = SVGsegs(tooth);
    // 將 toothData 旋轉半齒, 讓齒形以 x 軸為對稱中心
    // SVGsegs 自帶資料旋轉 rotate() 方法
    //toothData = toothData.rotate(180/n);
    // 利用 SVGsegs 自帶的 dup() 資料 duplicate 方法, 建立 gear 單齒資料
    var gearData = toothData.dup();
    // 利用單齒輪廓旋轉, 產生整個正齒輪外形
    for(i=1; i<n; i++){
        //將 toothData 中的資料複製到 newTooth
        //var newTooth = toothData.dup();
        //配合迴圈, newTooth 的齒形資料進行旋轉, 然後利用 appendPath 方法, 將資料併入 gear
        var newTooth = toothData.rotate(-360*i/n);
        print(i);
        gearData = gearData.joinPath(newTooth);
    }
    // diameter of gear shaft
    num hd = 0.6*pr;
    var shaft = circle(hd);
    gearData = gearData.appendPath(shaft);
    // rotate the tooth to put start of involute on the x axis
    // 目前 Path 中的 pitchToBaseAngle 旋轉無法作用
    num pitchToBaseAngle = (math.sqrt(pr*pr - rb*rb)/rb) - math.acos(rb/pr);
    var gearPath = Path(gearData, {'degs':180*pitchToBaseAngle/math.pi, 'x':-rb, 'strokeColor':'red'});
    var gearShape = Shape(gearData, {});
    var gearGroup = Group(gearShape);
    return gearPath;
}

    initGears(var opts)
    {
    // generate gears
    //gear = makeGearObj(gear1, gearCol, shaftCol, true);  // true = add mesh rotation
    //pinion = makeGearObj(gear2, pinionCol, shaftCol, true);
    //this.nextState.rot = 0;
    }
      
main() {
  var cgo = Cango("canvas");
  // setup the animation properties
  var gearConfig = {'degs':[0, 360]};
  var twnr = Tweener(0, 90000, "loop");   
  cgo.gridboxPadding(10, 10, 10, 10);
  // cgo.setWorldCoordsRHC([gbLowerLeftX, gbLowerLeftY, gbWidth [, gbHeight]]);
  // 省略 gbHeight 表示 Y scale 與 X 相同
  cgo.setWorldCoordsRHC(-100, -100, 300);
  // draw axes
  cgo.drawAxes(0, 70, 0, 70,
      {'xOrigin': 0, 'yOrigin': 0, 'fontSize': 10, 'strokeColor': 'gray'});
  var gear = cangoGear(20, 5, 20);
  // 必須利用 cgo.render() 顯示 Path 資料
  cgo.render(gear);
}
